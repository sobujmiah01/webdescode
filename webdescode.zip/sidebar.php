<aside>
    <?php dynamic_sidebar('sidebar'); ?>
</aside>